#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d server/node_modules ] || npm run setup
[ -d client/dist ] || npm run build
echo; echo "Open http://localhost:5000 in your browser"; echo
npm start
