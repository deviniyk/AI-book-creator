# AI Book Creator

> Your imagination. Your story. Your book.

Type a story idea, click **Generate my book**, and the app writes a complete book and gives you a standard PDF eBook:

- Front cover with the **book title and author name**
- Title page, copyright page, table of contents, characters
- All chapters with page numbers
- About the Author page
- Back cover with the summary

You can edit the title, author, summary and every chapter, regenerate any chapter, regenerate the cover artwork, then download the PDF. English, Sinhala and Tamil are supported (including in the PDF).

## Run it (one terminal, one command)

You need **Node.js 18 or newer** (https://nodejs.org).

**Windows:** double-click `start.bat`
**Mac/Linux:** run `./start.sh`

Or by hand, in this folder:

```
npm run setup      # first time only: installs everything and builds the website
npm start
```

Then open **http://localhost:5000**.

## Turn on the real AI

Without a key the app runs in **demo mode** (sample text, a designed cover) so you can try the whole flow.

1. Get an API key at https://platform.openai.com/api-keys (the API needs billing credit; it is separate from a ChatGPT subscription).
2. Open `server/.env`, paste the key after `OPENAI_API_KEY=` (no quotes, no spaces), and save.
3. Stop the server (Ctrl+C) and start it again. The yellow "Demo mode" bar disappears.

The key stays on the server and is never sent to the browser.

If cover artwork fails with `gpt-image-1` (it can require OpenAI organization verification), set in `server/.env`:
```
OPENAI_IMAGE_MODEL=dall-e-3
```
Books still get a designed cover with title and author even if artwork is unavailable.

## How it works

1. **/api/outline** plans the book: title, tagline, back-cover summary, characters, chapter list.
2. **/api/chapter** writes one chapter at a time (with the previous chapter for continuity). Also used by the Regenerate button.
3. **/api/cover** paints cover artwork with no text in it. The title and author are typeset by the app, so spelling is always right.
4. **/api/export-pdf** builds the A5 PDF with PDFKit.

## Developing

```
npm run dev:server     # API on :5000, auto restart
npm run dev:client     # website on :5173 with hot reload (proxies /api to :5000)
```

```
ai-book-creator/
  server/   index.js (routes), ai.js (OpenAI + demo mode), pdf.js (book layout), fonts/ (Sinhala + Tamil)
  client/   src/pages (Landing, Create, Studio, Library), src/api.js, src/storage.js
```

## Notes and limits

- Books are saved in your browser (localStorage) under My Books. Firebase login and cloud storage are the next step.
- Long books are written chapter by chapter, so a 10-chapter book can take a few minutes.
- This is an AI-assisted tool. Review the content before publishing, and make sure you have the rights to what you publish.
