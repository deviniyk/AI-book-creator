@echo off
cd /d "%~dp0"
if not exist server\node_modules (
  echo Installing for the first time, this takes a minute...
  call npm run setup
)
if not exist client\dist call npm run build
echo.
echo Open http://localhost:5000 in your browser
echo.
call npm start
pause
