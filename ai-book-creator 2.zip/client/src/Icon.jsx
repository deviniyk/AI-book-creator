import React from "react";

// Small line-icon set (24x24, stroke based)
const P = {
  bulb: (<><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" /><path d="M9 18h6" /><path d="M10 22h4" /></>),
  bot: (<><rect x="3" y="11" width="18" height="10" rx="2" /><circle cx="12" cy="5" r="2" /><path d="M12 7v4" /><path d="M8 16h.01" /><path d="M16 16h.01" /></>),
  palette: (<><path d="M12 3a9 9 0 1 0 0 18c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.2 0-1.1.9-2 2-2h2.3A4.2 4.2 0 0 0 21.5 10 9 9 0 0 0 12 3z" /><circle cx="7.5" cy="11" r="1" /><circle cx="10" cy="7" r="1" /><circle cx="15" cy="7" r="1" /></>),
  download: (<><path d="M12 3v12" /><path d="m7 10 5 5 5-5" /><path d="M5 21h14" /></>),
  wand: (<><path d="M4 20 15 9" /><path d="m14 4 .8 1.7L16.5 6.5l-1.7.8L14 9l-.8-1.7-1.7-.8 1.7-.8z" /><path d="m19 11 .5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5z" /></>),
  home: (<><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /></>),
  user: (<><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></>),
  logout: (<><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="m16 17 5-5-5-5" /><path d="M21 12H9" /></>),
  arrow: (<><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></>),
  chevR: <path d="m9 6 6 6-6 6" />,
  chevL: <path d="m15 6-6 6 6 6" />,
  chevD: <path d="m6 9 6 6 6-6" />,
  play: (<><circle cx="12" cy="12" r="10" /><path d="m10 8 6 4-6 4z" fill="currentColor" /></>),
  crown: <path d="M3 7l4 4 5-7 5 7 4-4-2 12H5z" />,
  shield: (<><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" /><path d="m9 12 2 2 4-4" /></>),
  mask: (<><path d="M3 5h18v6c0 5-4 8-9 8s-9-3-9-8z" /><path d="M8 10h.01" /><path d="M16 10h.01" /><path d="M9 14c1.5 1.3 4.5 1.3 6 0" /></>),
  globe: (<><circle cx="12" cy="12" r="9" /><path d="M3 12h18" /><path d="M12 3c3 3 3 15 0 18-3-3-3-15 0-18z" /></>),
  users: (<><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5" /><circle cx="17" cy="9" r="2.5" /><path d="M17 14.5c2.5 0 4.5 1.5 4.5 4.5" /></>),
  book: (<><path d="M2 4h7a3 3 0 0 1 3 3v14a2 2 0 0 0-2-2H2z" /><path d="M22 4h-7a3 3 0 0 0-3 3v14a2 2 0 0 1 2-2h8z" /></>),
  pencil: (<><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" /></>),
  sun: (<><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>),
  moon: <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />,
  sparkle: <path d="M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8z" fill="currentColor" stroke="none" />,
  quill: (<><path d="M20 3c-7 0-13 4-14 12l-2 6 6-2c8-1 12-7 12-14z" /><path d="M4 21 14 11" /></>),
  menu: (<><path d="M4 6h16" /><path d="M4 12h16" /><path d="M4 18h16" /></>),
  close: (<><path d="M6 6l12 12" /><path d="M18 6 6 18" /></>),
  check: <path d="m5 12 5 5 9-10" />,
};

export default function Icon({ name, size = 20, className = "", strokeWidth = 1.8 }) {
  return (
    <svg
      className={`icon ${className}`}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {P[name]}
    </svg>
  );
}

export function Logo({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <defs>
        <linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#7a54d6" />
          <stop offset="1" stopColor="#3b2a6b" />
        </linearGradient>
      </defs>
      <path d="M24 12c-4-3-11-3-18-1v28c7-2 14-2 18 1z" fill="url(#lg1)" />
      <path d="M24 12c4-3 11-3 18-1v28c-7-2-14-2-18 1z" fill="#e8a94a" />
      <path d="M24 12v28" stroke="#fff4d6" strokeWidth="1.5" />
      <path d="M12 18c3-.7 6-.5 9 .8M12 24c3-.7 6-.5 9 .8" stroke="#fff" strokeOpacity=".55" strokeWidth="1.4" fill="none" />
      <path d="M24 4l1.2 3.3 3.3 1.2-3.3 1.2L24 13l-1.2-3.3-3.3-1.2 3.3-1.2z" fill="#f6c453" />
    </svg>
  );
}
