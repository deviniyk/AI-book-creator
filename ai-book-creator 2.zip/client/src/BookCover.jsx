import React from "react";

// Cover preview. AI artwork (no text) with the title/author typeset by the app,
// or a designed cover (gradient + gold frame) when there is no artwork.
export default function BookCover({ book, image, back = false }) {
  const style = image ? { backgroundImage: `url(${image})` } : {};
  const cls = "cover" + (image ? "" : " designed") + (back ? " back" : "");
  if (back) {
    return (
      <div className={cls} style={style}>
        <div className="cover-panel">
          <h3>{book.title}</h3>
          <p>{book.summary}</p>
          <em>{book.author}</em>
        </div>
      </div>
    );
  }
  return (
    <div className={cls} style={style}>
      <div className="cover-top">
        <h2>{book.title}</h2>
        {book.tagline && <p>{book.tagline}</p>}
      </div>
      <div className="cover-bottom">{book.author}</div>
    </div>
  );
}
