// MVP storage: browser localStorage. Swap these functions for Firebase (Stage 5)
// without touching the pages.
const KEY = "aibc_books";

export function listBooks() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || [];
  } catch {
    return [];
  }
}

export function getBook(id) {
  return listBooks().find((b) => b.id === id);
}

export function saveBook(entry) {
  const books = listBooks();
  const i = books.findIndex((b) => b.id === entry.id);
  if (i >= 0) books[i] = entry;
  else books.unshift(entry);
  try {
    localStorage.setItem(KEY, JSON.stringify(books));
  } catch {
    // covers are large; if storage is full, retry without images
    const lite = books.map((b) => ({ ...b, frontCover: null, backCover: null }));
    localStorage.setItem(KEY, JSON.stringify(lite));
  }
  return entry;
}

export function deleteBook(id) {
  localStorage.setItem(KEY, JSON.stringify(listBooks().filter((b) => b.id !== id)));
}

export function newId() {
  return "bk_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
