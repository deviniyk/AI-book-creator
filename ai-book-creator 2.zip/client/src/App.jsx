import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Navbar from "./Navbar.jsx";
import LoginModal from "./LoginModal.jsx";
import Landing from "./pages/Landing.jsx";
import Create from "./pages/Create.jsx";
import Studio from "./pages/Studio.jsx";
import Library from "./pages/Library.jsx";
import { About, FAQ } from "./pages/Info.jsx";
import { getStatus } from "./api.js";

function StatusBanner() {
  const [s, setS] = React.useState(null);
  React.useEffect(() => { getStatus().then(setS); }, []);
  if (!s) return null;
  if (!s.ok)
    return (
      <div className="banner bad">
        The backend server is not running. In the project folder run <code>npm start</code>, then refresh this page.
      </div>
    );
  if (s.mode === "demo")
    return (
      <div className="banner">
        <strong>Demo mode:</strong> no OpenAI key found, so books use sample text and a designed cover. Add your key to{" "}
        <code>server/.env</code> and restart for real AI stories and cover art.
      </div>
    );
  return null;
}

export default function App() {
  const { pathname } = useLocation();
  const page = pathname === "/" ? "home" : pathname.startsWith("/create") ? "create" : "inner";
  return (
    <div className="app" data-page={page}>
      <Navbar />
      <StatusBanner />
      <main>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/create" element={<Create />} />
          <Route path="/studio/:id" element={<Studio />} />
          <Route path="/library" element={<Library />} />
          <Route path="/about" element={<About />} />
          <Route path="/faq" element={<FAQ />} />
        </Routes>
      </main>
      <footer className="footer">
        Books are AI-assisted from the author's original idea. Review the content before publishing or sharing.
      </footer>
      <LoginModal />
    </div>
  );
}
