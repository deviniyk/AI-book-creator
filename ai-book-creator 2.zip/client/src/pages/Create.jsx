import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Icon from "../Icon.jsx";
import { CreateArt } from "../art.jsx";
import { useAuth } from "../auth.jsx";
import { generateOutline, writeChapter, generateCover, getStatus, withRetry } from "../api.js";
import { saveBook, newId } from "../storage.js";

const GENRES = ["Fantasy", "Adventure", "Mystery", "Romance", "Science Fiction", "Horror", "Children's Story", "Historical"];
const LANGUAGES = [["English", "EN"], ["Sinhala", "සිං"], ["Tamil", "த"]];

// story length -> how many chapters / how long each one is (A5 pages: roughly 350 words per page)
const LENGTHS = {
  short: { label: "Short (5 – 10 pages)", chapters: 4, words: 450 },
  medium: { label: "Medium (15 – 25 pages)", chapters: 7, words: 700 },
  long: { label: "Long (30 – 50 pages)", chapters: 12, words: 900 },
};
const CHARACTERS = [
  ["few", "2 – 4 Characters", 3],
  ["some", "5 – 8 Characters", 6],
  ["many", "9 – 12 Characters", 10],
];

function Field({ icon, label, children, className = "" }) {
  return (
    <label className={`field ${className}`}>
      <span className="field-label"><Icon name={icon} size={19} /> {label}</span>
      {children}
    </label>
  );
}

export default function Create() {
  const nav = useNavigate();
  const { user } = useAuth();
  const [form, setForm] = useState({
    idea: "",
    genre: "Fantasy",
    language: "English",
    characters: "some",
    length: "short",
    authorName: user?.name || "",
  });
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState({ text: "", pct: 0 });
  const [error, setError] = useState("");

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const langBadge = LANGUAGES.find(([l]) => l === form.language)?.[1];

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const preset = LENGTHS[form.length];
      const n = preset.chapters;
      const characterCount = CHARACTERS.find(([k]) => k === form.characters)[2];
      const authorName = form.authorName.trim() || user?.name || "";

      setProgress({ text: "Planning your book: title, characters and chapters...", pct: 4 });
      const outline = await withRetry(() =>
        generateOutline({ idea: form.idea, genre: form.genre, language: form.language, chapters: n, length: form.length, authorName, characterCount })
      );

      const chapters = [];
      let previousText = "";
      for (let i = 0; i < n; i++) {
        setProgress({
          text: `Writing chapter ${i + 1} of ${n}: ${outline.chapters[i].title}`,
          pct: 8 + Math.round((i / n) * 72),
        });
        const { content } = await withRetry(() =>
          writeChapter({ outline, index: i, previousText, length: form.length, wordsPerChapter: preset.words })
        );
        chapters.push({ ...outline.chapters[i], content });
        previousText = content;
      }
      const book = { ...outline, chapters };

      let frontCover = null, backCover = null, notice = "";
      const status = await getStatus();
      if (status.mode === "openai") {
        setProgress({ text: "Painting the front and back cover...", pct: 85 });
        try {
          const [f, b] = await Promise.all([
            withRetry(() => generateCover({ coverPrompt: book.coverPrompt, side: "front" }), 2),
            withRetry(() => generateCover({ coverPrompt: book.coverPrompt, side: "back" }), 2),
          ]);
          frontCover = f.image;
          backCover = b.image;
        } catch (err) {
          notice = `Cover artwork could not be created (${err.message}). A designed cover with your title and name is used instead; you can retry in the Design Studio.`;
        }
      }

      setProgress({ text: "Finishing your book...", pct: 97 });
      const id = newId();
      saveBook({ id, book, length: form.length, wordsPerChapter: preset.words, frontCover, backCover, notice, updatedAt: Date.now() });
      nav(`/studio/${id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <div className="create-page">
      <CreateArt />
      <section className="create-inner">
        <div className="create-title">
          <div className="ornament"><span /><Icon name="quill" size={34} strokeWidth={1.5} className="gold" /><span /></div>
          <h1>Create Your Story</h1>
          <p>Share your idea, and let AI turn it into a complete book! <Icon name="sparkle" size={18} className="gold" /></p>
        </div>
        <p className="script side">Turn your imagination<br />into a beautiful book <Icon name="sparkle" size={18} className="gold" /></p>

        <form className="create-card" onSubmit={submit}>
          <div className="idea-head">
            <span className="idea-icon"><Icon name="bulb" size={26} /></span>
            <b>Your Story Idea</b>
          </div>
          <textarea
            className="idea"
            rows={4}
            required
            minLength={10}
            maxLength={500}
            disabled={busy}
            placeholder="A short idea... (e.g. A girl finds a magical key and enters a hidden world...)"
            value={form.idea}
            onChange={set("idea")}
          />
          <div className="counter">{form.idea.length}/500</div>

          <div className="grid2">
            <Field icon="mask" label="Genre">
              <span className="select">
                <select disabled={busy} value={form.genre} onChange={set("genre")}>
                  {GENRES.map((g) => <option key={g}>{g}</option>)}
                </select>
                <Icon name="chevD" size={16} />
              </span>
            </Field>
            <Field icon="globe" label="Language">
              <span className="select">
                <em className="flag">{langBadge}</em>
                <select disabled={busy} value={form.language} onChange={set("language")}>
                  {LANGUAGES.map(([l]) => <option key={l}>{l}</option>)}
                </select>
                <Icon name="chevD" size={16} />
              </span>
            </Field>
            <Field icon="users" label="Character Count">
              <span className="select">
                <select disabled={busy} value={form.characters} onChange={set("characters")}>
                  {CHARACTERS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                </select>
                <Icon name="chevD" size={16} />
              </span>
            </Field>
            <Field icon="book" label="Story Length">
              <span className="select">
                <select disabled={busy} value={form.length} onChange={set("length")}>
                  {Object.entries(LENGTHS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
                <Icon name="chevD" size={16} />
              </span>
            </Field>
          </div>

          <Field icon="pencil" label="Author Name (optional)" className="author">
            <input disabled={busy} placeholder="Your Name" value={form.authorName} onChange={set("authorName")} />
          </Field>

          {error && <p className="error">{error}</p>}

          {busy ? (
            <div className="progress">
              <div className="bar"><div style={{ width: `${progress.pct}%` }} /></div>
              <p>{progress.text}</p>
              <small>A full book can take a few minutes. Please keep this page open.</small>
            </div>
          ) : (
            <button className="btn gen"><Icon name="wand" size={22} /> Generate My Book <Icon name="arrow" size={19} /></button>
          )}
        </form>

        <p className="safe"><span /><Icon name="shield" size={20} /> Your books are saved on this device. Create, explore and enjoy! <span /></p>
      </section>
    </div>
  );
}
