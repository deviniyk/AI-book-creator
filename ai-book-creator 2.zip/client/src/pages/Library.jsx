import React, { useState } from "react";
import { Link } from "react-router-dom";
import { listBooks, deleteBook } from "../storage.js";
import BookCover from "../BookCover.jsx";

export default function Library() {
  const [books, setBooks] = useState(listBooks());

  function remove(id) {
    if (!confirm("Delete this book?")) return;
    deleteBook(id);
    setBooks(listBooks());
  }

  return (
    <section className="panel">
      <h1>My Books</h1>
      {books.length === 0 && (
        <p>No books yet. <Link to="/create">Create your first one</Link>.</p>
      )}
      <div className="shelf">
        {books.map((b) => (
          <div className="shelf-item" key={b.id}>
            <Link to={`/studio/${b.id}`}>
              <BookCover book={b.book} image={b.frontCover} />
            </Link>
            <button className="link danger" onClick={() => remove(b.id)}>Delete</button>
          </div>
        ))}
      </div>
    </section>
  );
}
