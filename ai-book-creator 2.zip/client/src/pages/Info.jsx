import React, { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../Icon.jsx";

export function About() {
  return (
    <section className="page-card">
      <h1>About AI Book Creator</h1>
      <p className="lead-dark">
        AI Book Creator turns a short story idea into a complete eBook: a planned story, written chapters, front and back covers,
        and a standard PDF with contents and page numbers. The idea is yours; the AI helps you bring it to the page.
      </p>
      <div className="about-grid">
        <div className="card"><Icon name="bulb" size={26} /><h3>You bring the idea</h3><p>Describe your story in a few sentences, choose the genre, language and length, and add your name as the author.</p></div>
        <div className="card"><Icon name="bot" size={26} /><h3>AI writes with you</h3><p>The story is planned, then written chapter by chapter so characters and events stay consistent. Edit or regenerate anything.</p></div>
        <div className="card"><Icon name="palette" size={26} /><h3>A real book design</h3><p>Cover artwork is painted without text. Your title and name are typeset on top, so spelling is always correct in any language.</p></div>
      </div>
      <h2>Ownership and responsible use</h2>
      <p>Books are AI-assisted. Please read and edit your book before sharing it, and make sure the idea you start from is your own. Every PDF includes a note that the book was created with AI assistance.</p>
      <Link className="btn green" to="/create">Create Your Book <Icon name="arrow" size={17} /></Link>
    </section>
  );
}

const QA = [
  ["Is it free?", "The app itself is free to run. Writing stories and painting covers uses the OpenAI API, which is billed by OpenAI per use. In demo mode (no key) nothing is charged and sample text is used."],
  ["Which languages are supported?", "English, Sinhala and Tamil, including in the downloaded PDF."],
  ["Who owns the book?", "You are credited as the author because the story starts from your idea. AI-generated content can have different legal treatment in different countries, so check the rules where you plan to publish."],
  ["Can I edit the story?", "Yes. In the Edit Story tab you can change any chapter, rewrite a chapter with AI, and edit the title, tagline, author name and back-cover summary."],
  ["What is in the PDF?", "Front cover with title and author, title page, copyright page, contents, characters, numbered chapters, About the Author and a back cover with the summary."],
  ["Where are my books stored?", "In this browser, on this device. Clearing your browser data removes them, so download the PDF of any book you want to keep."],
  ["Why do I see Demo mode?", "No OpenAI API key was found on the server. Add it to server/.env and restart to get real AI stories and cover artwork."],
];

export function FAQ() {
  const [open, setOpen] = useState(0);
  return (
    <section className="page-card narrow">
      <h1>Frequently Asked Questions</h1>
      {QA.map(([q, a], i) => (
        <div key={q} className={`faq ${open === i ? "open" : ""}`}>
          <button onClick={() => setOpen(open === i ? -1 : i)}>
            {q}
            <Icon name="chevD" size={18} />
          </button>
          {open === i && <p>{a}</p>}
        </div>
      ))}
    </section>
  );
}
