import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getBook, saveBook } from "../storage.js";
import { generateCover, writeChapter, downloadPdf, getStatus } from "../api.js";
import BookCover from "../BookCover.jsx";

const STYLES = ["illustrated storybook", "watercolor", "dramatic cinematic", "minimal modern", "vintage poster"];

export default function Studio() {
  const { id } = useParams();
  const [entry, setEntry] = useState(() => getBook(id));
  const [tab, setTab] = useState("design");
  const [style, setStyle] = useState(STYLES[0]);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");

  if (!entry)
    return (
      <section className="panel">
        <p>Book not found. <Link to="/library">Go to My Books</Link></p>
      </section>
    );

  const { book, frontCover, backCover } = entry;

  function update(patch) {
    const next = { ...entry, ...patch, updatedAt: Date.now() };
    setEntry(next);
    saveBook(next);
  }
  const setBookField = (k) => (e) => update({ book: { ...book, [k]: e.target.value } });
  const setChapter = (i, k, v) => {
    const chapters = book.chapters.map((c, j) => (j === i ? { ...c, [k]: v } : c));
    update({ book: { ...book, chapters } });
  };

  async function run(label, fn) {
    setError("");
    setBusy(label);
    try {
      await fn();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy("");
    }
  }

  const makeCovers = () =>
    run("covers", async () => {
      const status = await getStatus();
      if (status.mode !== "openai") throw new Error("Cover artwork needs your OpenAI key. Add it to server/.env and restart the server. Until then the designed cover is used.");
      const [f, b] = await Promise.all([
        generateCover({ coverPrompt: book.coverPrompt, side: "front", style }),
        generateCover({ coverPrompt: book.coverPrompt, side: "back", style }),
      ]);
      update({ frontCover: f.image, backCover: b.image, notice: "" });
    });

  const rewrite = (i) =>
    run("chapter" + i, async () => {
      const instruction = prompt("Anything specific for the rewrite? (optional)") || "";
      const previousText = i > 0 ? book.chapters[i - 1].content : "";
      const { content } = await writeChapter({ outline: book, index: i, previousText, instruction, length: entry.length || "medium" });
      setChapter(i, "content", content);
    });

  const pdf = () => run("pdf", () => downloadPdf({ book, frontCover, backCover }));

  return (
    <section className="panel">
      <div className="studio-head">
        <div>
          <h1>{book.title}</h1>
          <p className="by">by {book.author}</p>
        </div>
        <button className="btn primary big" onClick={pdf} disabled={!!busy}>
          {busy === "pdf" ? "Building PDF..." : "⬇ Download PDF eBook"}
        </button>
      </div>
      {entry.notice && <p className="note">{entry.notice}</p>}
      {error && <p className="error">{error}</p>}

      <div className="tabs">
        {[["design", "Design Studio"], ["edit", "Edit Story"], ["read", "Read Book"]].map(([k, l]) => (
          <button key={k} className={tab === k ? "active" : ""} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {tab === "design" && (
        <div className="studio-grid">
          <div className="covers">
            <div><p className="cap">Front cover</p><BookCover book={book} image={frontCover} /></div>
            <div><p className="cap">Back cover</p><BookCover book={book} image={backCover} back /></div>
          </div>
          <div className="form">
            <label>Book title<input value={book.title} onChange={setBookField("title")} /></label>
            <label>Tagline<input value={book.tagline || ""} onChange={setBookField("tagline")} /></label>
            <label>Author name<input value={book.author || ""} onChange={setBookField("author")} /></label>
            <label>Back cover summary<textarea rows={5} value={book.summary || ""} onChange={setBookField("summary")} /></label>
            <label>Cover artwork description<textarea rows={3} value={book.coverPrompt || ""} onChange={setBookField("coverPrompt")} /></label>
            <label>Cover style
              <select value={style} onChange={(e) => setStyle(e.target.value)}>
                {STYLES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </label>
            <button className="btn" onClick={makeCovers} disabled={!!busy}>
              {busy === "covers" ? "Painting covers..." : frontCover ? "Regenerate cover artwork" : "Generate cover artwork"}
            </button>
          </div>
        </div>
      )}

      {tab === "edit" && (
        <div className="chapters">
          {book.chapters.map((c, i) => (
            <div className="card" key={i}>
              <div className="row between">
                <input className="chapter-title" value={c.title} onChange={(e) => setChapter(i, "title", e.target.value)} />
                <button className="btn small" onClick={() => rewrite(i)} disabled={!!busy}>
                  {busy === "chapter" + i ? "Rewriting..." : "Regenerate"}
                </button>
              </div>
              <textarea rows={12} value={c.content} onChange={(e) => setChapter(i, "content", e.target.value)} />
            </div>
          ))}
        </div>
      )}

      {tab === "read" && (
        <article className="reader">
          <h1>{book.title}</h1>
          <p className="by">by {book.author}</p>
          {book.characters?.length > 0 && (
            <>
              <h2>Characters</h2>
              {book.characters.map((c, i) => <p key={i}><strong>{c.name}.</strong> {c.description}</p>)}
            </>
          )}
          {book.chapters.map((c) => (
            <div key={c.number}>
              <h2>Chapter {c.number}: {c.title}</h2>
              {String(c.content).split(/\n+/).map((p, i) => p.trim() && <p key={i}>{p}</p>)}
            </div>
          ))}
        </article>
      )}
    </section>
  );
}
