import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../Icon.jsx";
import { HeroArt, ExampleCover, EXAMPLES } from "../art.jsx";

const STEPS = [
  ["bulb", "tint-green", "1. Share Your Idea", "Enter a short story idea and choose your preferences."],
  ["bot", "tint-purple", "2. Let AI Create", "Generate a complete story with chapters."],
  ["palette", "tint-orange", "3. Get Stunning Covers", "Beautiful front & back covers are designed for you."],
  ["download", "tint-teal", "4. Download Your Book", "Get your eBook in PDF format."],
];

// ---- demo player: a short animated walkthrough of the four steps
const IDEA = "A young girl discovers a magical forest where animals can talk to humans...";
function DemoModal({ onClose }) {
  const [step, setStep] = useState(0);
  const [typed, setTyped] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setStep((s) => (s + 1) % 4), 3600);
    return () => clearTimeout(t);
  }, [step]);
  useEffect(() => {
    if (step !== 0) return;
    setTyped("");
    let i = 0;
    const t = setInterval(() => { i += 2; setTyped(IDEA.slice(0, i)); if (i >= IDEA.length) clearInterval(t); }, 45);
    return () => clearInterval(t);
  }, [step]);

  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal demo" onClick={(e) => e.stopPropagation()}>
        <button className="modal-x" onClick={onClose} aria-label="Close"><Icon name="close" size={18} /></button>
        <h2>See how it works</h2>
        <div className="demo-stage">
          {step === 0 && (
            <div className="demo-card">
              <b>Your story idea</b>
              <p className="typed">{typed}<i className="caret" /></p>
              <div className="demo-chips"><span>Fantasy</span><span>English</span><span>Short</span></div>
            </div>
          )}
          {step === 1 && (
            <div className="demo-card">
              <b>The Secret of the Whispering Forest</b>
              {["The Hidden Path", "A Voice in the Trees", "The Fox Who Knew", "The Heart of the Forest", "Home Again"].map((c, i) => (
                <p key={c} className="chap" style={{ animationDelay: `${i * 0.35}s` }}><Icon name="check" size={15} /> Chapter {i + 1}: {c}</p>
              ))}
            </div>
          )}
          {step === 2 && (
            <div className="demo-covers">
              <ExampleCover kind="forest" />
              <ExampleCover kind="stars" />
            </div>
          )}
          {step === 3 && (
            <div className="demo-card center">
              <Icon name="download" size={44} />
              <b>Your eBook is ready</b>
              <p className="muted">Cover, contents, chapters and back cover in one PDF.</p>
              <span className="btn primary">Download PDF</span>
            </div>
          )}
        </div>
        <div className="dots">
          {STEPS.map((s, i) => (
            <button key={i} className={i === step ? "on" : ""} onClick={() => setStep(i)} aria-label={`Step ${i + 1}`} />
          ))}
        </div>
        <p className="muted center-text">{STEPS[step][2]}: {STEPS[step][3]}</p>
        <Link className="btn green wide" to="/create" onClick={onClose}>Create Your Book <Icon name="arrow" size={17} /></Link>
      </div>
    </div>
  );
}

function Carousel() {
  const ref = useRef(null);
  const go = (dir) => ref.current?.scrollBy({ left: dir * 260, behavior: "smooth" });
  return (
    <div className="carousel">
      <button className="round" onClick={() => go(-1)} aria-label="Previous"><Icon name="chevL" size={20} /></button>
      <div className="car-track" ref={ref}>
        {EXAMPLES.map((k) => (
          <Link to="/create" key={k} className="car-item" title="Create a book like this">
            <ExampleCover kind={k} />
          </Link>
        ))}
      </div>
      <button className="round" onClick={() => go(1)} aria-label="Next"><Icon name="chevR" size={20} /></button>
    </div>
  );
}

export default function Landing() {
  const [demo, setDemo] = useState(false);
  return (
    <>
      <section className="hero">
        <HeroArt />
        <div className="hero-fade" />
        <div className="hero-inner">
          <span className="badge"><Icon name="sparkle" size={15} className="gold" /> Turn Your Ideas into Amazing Books</span>
          <h1>
            Your imagination.<br />
            Your story. <span className="hl">Your book.
              <svg viewBox="0 0 260 14" preserveAspectRatio="none" aria-hidden="true"><path d="M2 10 C 60 2, 150 2, 258 8" stroke="#e0a63c" strokeWidth="3" fill="none" strokeLinecap="round" /></svg>
            </span>
          </h1>
          <p className="lead">
            Share a simple idea, and let AI create a complete eBook — with a captivating story, beautiful covers, and more!
          </p>
          <div className="hero-actions">
            <Link className="btn green big" to="/create"><Icon name="wand" size={19} /> Create Your Book <Icon name="arrow" size={17} /></Link>
            <button className="btn ghost big" onClick={() => setDemo(true)}><Icon name="play" size={26} strokeWidth={1.6} /> Watch Demo</button>
          </div>
        </div>
        <p className="script">Dream it…<br />Write it…<br />Read it…</p>
      </section>

      <section className="how">
        <h2 className="h-fancy"><span /><Icon name="sparkle" size={22} className="gold" /> How It Works <span /></h2>
        <p className="sub"><i /> Just a few simple steps to create your masterpiece <i /></p>
        <div className="how-row">
          {STEPS.map(([icon, tint, title, text], i) => (
            <React.Fragment key={title}>
              <div className="how-card">
                <div className={`how-icon ${tint}`}><Icon name={icon} size={30} /></div>
                <div>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </div>
              </div>
              {i < STEPS.length - 1 && <Icon name="chevR" size={20} className="how-arrow" />}
            </React.Fragment>
          ))}
        </div>
      </section>

      <section className="examples">
        <h2 className="h-fancy"><span /><Icon name="book" size={24} className="gold" /> Example Books <span /></h2>
        <Carousel />
      </section>

      <section className="cta-wrap">
        <div className="cta-bar">
          <Icon name="crown" size={34} className="gold" strokeWidth={1.6} />
          <div>
            <b>Be the Author of Your Own Story</b>
            <p>Create, explore, and share your books with the world.</p>
          </div>
          <Link className="btn cream" to="/create">Get Started <Icon name="arrow" size={17} /></Link>
        </div>
      </section>

      {demo && <DemoModal onClose={() => setDemo(false)} />}
    </>
  );
}
