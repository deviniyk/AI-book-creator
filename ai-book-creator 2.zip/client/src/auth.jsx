import React, { createContext, useContext, useEffect, useState } from "react";

// Local profile only (stored in this browser). Cloud accounts (Firebase) come later.
const KEY = "aibc_user";
const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; }
  });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    try {
      if (user) localStorage.setItem(KEY, JSON.stringify(user));
      else localStorage.removeItem(KEY);
    } catch { /* storage blocked */ }
  }, [user]);

  return (
    <AuthCtx.Provider value={{ user, login: setUser, logout: () => setUser(null), open, openLogin: () => setOpen(true), closeLogin: () => setOpen(false) }}>
      {children}
    </AuthCtx.Provider>
  );
}

export const useAuth = () => useContext(AuthCtx);

// light / dark theme
export function useTheme() {
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem("aibc_theme") || "light"; } catch { return "light"; }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem("aibc_theme", theme); } catch { /* ignore */ }
  }, [theme]);
  return [theme, () => setTheme((t) => (t === "light" ? "dark" : "light"))];
}
