import React, { useMemo } from "react";

// deterministic pseudo-random so sparkles don't move between renders
function rng(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sparkles(n, x0, y0, x1, y1, seed) {
  const r = rng(seed);
  return Array.from({ length: n }, () => ({
    x: x0 + r() * (x1 - x0),
    y: y0 + r() * (y1 - y0),
    s: 0.8 + r() * 2.6,
    o: 0.4 + r() * 0.6,
  }));
}

function Star({ x, y, s = 6, fill = "#fff2b8" }) {
  return (
    <path
      transform={`translate(${x} ${y}) scale(${s / 6})`}
      d="M0 -8 L1.6 -1.6 L8 0 L1.6 1.6 L0 8 L-1.6 1.6 L-8 0 L-1.6 -1.6Z"
      fill={fill}
    />
  );
}

function Castle({ x = 0, y = 0, scale = 1, fill = "#4a3f86", glow = true }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <rect x="0" y="110" width="140" height="50" fill={fill} />
      <rect x="10" y="70" width="18" height="90" fill={fill} />
      <polygon points="8,70 19,34 30,70" fill={fill} />
      <rect x="52" y="28" width="28" height="132" fill={fill} />
      <polygon points="49,28 66,-26 83,28" fill={fill} />
      <rect x="104" y="58" width="22" height="102" fill={fill} />
      <polygon points="101,58 115,18 129,58" fill={fill} />
      <rect x="34" y="92" width="14" height="68" fill={fill} />
      <polygon points="32,92 41,66 50,92" fill={fill} />
      <path d="M66 -26V-40" stroke={fill} strokeWidth="2" />
      <path d="M66 -40l14 4-14 4z" fill="#e8a94a" />
      {glow && (
        <g fill="#ffd27a">
          <rect x="62" y="50" width="6" height="10" rx="2" />
          <rect x="62" y="80" width="6" height="10" rx="2" />
          <rect x="16" y="90" width="4" height="8" rx="2" />
          <rect x="112" y="80" width="4" height="8" rx="2" />
          <rect x="38" y="115" width="5" height="9" rx="2" />
          <rect x="90" y="122" width="5" height="9" rx="2" />
        </g>
      )}
    </g>
  );
}

function MagicBook({ cx, cy, w = 1 }) {
  return (
    <g transform={`translate(${cx} ${cy}) scale(${w})`}>
      <ellipse cx="0" cy="-30" rx="190" ry="120" fill="url(#glow)" />
      <path d="M-210 15 L-198 80 C-130 55 -55 62 0 88 C55 62 130 55 198 80 L210 15 Z" fill="#6b3f2a" />
      <path d="M0 5 C-50 -26 -130 -26 -190 5 L-182 66 C-122 44 -52 50 0 72 Z" fill="#f9edd3" />
      <path d="M0 5 C50 -26 130 -26 190 5 L182 66 C122 44 52 50 0 72 Z" fill="#fff6e4" />
      <g stroke="#dcc79c" strokeWidth="1.4" fill="none" opacity=".9">
        <path d="M-20 14 C-70 -4 -120 -4 -165 18" />
        <path d="M-20 26 C-70 8 -120 8 -165 30" />
        <path d="M-20 38 C-70 20 -120 20 -165 42" />
        <path d="M20 14 C70 -4 120 -4 165 18" />
        <path d="M20 26 C70 8 120 8 165 30" />
        <path d="M20 38 C70 20 120 20 165 42" />
      </g>
      <path d="M0 5 V72" stroke="#c9a96b" strokeWidth="2" />
    </g>
  );
}

// ---------------------------------------------------------------- landing hero
export function HeroArt() {
  const sp = useMemo(() => sparkles(70, 330, 40, 700, 430, 11), []);
  const stars = useMemo(() => sparkles(10, 380, 60, 690, 360, 5), []);
  return (
    <svg className="hero-art" viewBox="0 0 900 560" preserveAspectRatio="xMaxYMax slice" aria-hidden="true">
      <defs>
        <linearGradient id="h-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f6d6e6" />
          <stop offset=".45" stopColor="#c9b3ee" />
          <stop offset="1" stopColor="#f8dcc9" />
        </linearGradient>
        <radialGradient id="glow" cx=".5" cy=".5" r=".5">
          <stop offset="0" stopColor="#fff6cf" stopOpacity="1" />
          <stop offset=".35" stopColor="#ffd072" stopOpacity=".75" />
          <stop offset="1" stopColor="#ff9f5a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="swirl" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#ffe9a8" />
          <stop offset="1" stopColor="#ffbf5e" />
        </linearGradient>
        <linearGradient id="table" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c98a57" />
          <stop offset="1" stopColor="#8f5632" />
        </linearGradient>
        <filter id="soft"><feGaussianBlur stdDeviation="5" /></filter>
        <filter id="soft2"><feGaussianBlur stdDeviation="14" /></filter>
      </defs>
      <rect width="900" height="560" fill="url(#h-sky)" />
      <ellipse cx="540" cy="330" rx="230" ry="120" fill="#fff3d8" opacity=".5" filter="url(#soft2)" />
      <g fill="#fff" opacity=".35">
        <ellipse cx="170" cy="120" rx="110" ry="22" />
        <ellipse cx="760" cy="90" rx="120" ry="20" />
        <ellipse cx="640" cy="200" rx="90" ry="14" />
      </g>
      <path d="M0 330 L110 255 L215 315 L330 215 L455 320 L565 262 L700 332 L820 248 L900 300 V560 H0Z" fill="#b7a4de" opacity=".65" />
      <path d="M0 385 L140 305 L262 372 L385 292 L520 382 L660 312 L800 392 L900 342 V560 H0Z" fill="#8c94c9" opacity=".8" />
      <path d="M0 440 L120 380 L260 430 L400 372 L560 440 L720 380 L900 430 V560 H0Z" fill="#6f7fb4" opacity=".85" />
      {/* castle on hill */}
      <path d="M420 372 Q560 280 710 372 V420 H420Z" fill="#59639f" />
      <Castle x={495} y={215} scale={1} />
      {/* swirl of magic from the book to the castle */}
      <g fill="none" strokeLinecap="round">
        <path d="M455 410 C 380 345, 560 350, 520 285 S 660 250, 590 170 S 700 120, 640 60" stroke="url(#swirl)" strokeWidth="16" filter="url(#soft)" opacity=".85" />
        <path d="M455 410 C 380 345, 560 350, 520 285 S 660 250, 590 170 S 700 120, 640 60" stroke="#fff6cf" strokeWidth="3" />
        <path d="M480 405 C 440 360, 590 330, 560 270 S 690 230, 640 170" stroke="url(#swirl)" strokeWidth="5" opacity=".9" />
      </g>
      {sp.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={p.s} fill="#fff1b0" opacity={p.o} />)}
      {stars.map((p, i) => <Star key={i} x={p.x} y={p.y} s={5 + p.s * 2} />)}
      {/* floating pages */}
      <g fill="#fbf0d8" stroke="#e1cda3">
        <path transform="translate(715 75) rotate(25)" d="M0 0 L46 -8 L40 30 L-6 38Z" />
        <path transform="translate(590 120) rotate(-18)" d="M0 0 L34 4 L28 34 L-6 30Z" />
        <path transform="translate(330 262) rotate(-30)" d="M0 0 L58 -6 L52 40 L-4 44Z" />
      </g>
      {/* table + book */}
      <path d="M0 505 Q 300 470 900 505 V560 H0Z" fill="url(#table)" />
      <MagicBook cx={470} cy={440} />
      {/* lantern */}
      <g transform="translate(775 380)">
        <ellipse cx="0" cy="40" rx="80" ry="90" fill="url(#glow)" opacity=".9" />
        <path d="M-18 -30 Q0 -60 18 -30" stroke="#3a2a22" strokeWidth="4" fill="none" />
        <rect x="-24" y="-30" width="48" height="10" rx="3" fill="#3a2a22" />
        <rect x="-20" y="-20" width="40" height="82" rx="6" fill="#ffd27a" opacity=".92" />
        <rect x="-20" y="-20" width="40" height="82" rx="6" fill="none" stroke="#3a2a22" strokeWidth="4" />
        <path d="M0 -20V62M-20 20H20" stroke="#3a2a22" strokeWidth="3" />
        <rect x="-26" y="62" width="52" height="12" rx="3" fill="#3a2a22" />
        <ellipse cx="0" cy="26" rx="10" ry="16" fill="#fff6cf" />
      </g>
      {/* book stack */}
      <g>
        <rect x="705" y="492" width="150" height="24" rx="3" fill="#3f2b2e" />
        <rect x="715" y="470" width="135" height="22" rx="3" fill="#7a3f36" />
        <rect x="722" y="450" width="118" height="20" rx="3" fill="#b28a52" />
        <path d="M715 482h135M722 460h118" stroke="#e8c776" strokeWidth="1.4" />
      </g>
      {/* bookshelf in the corner: fades softly into the sky so it never looks like a hard block */}
      <defs>
        <radialGradient id="shelf-fade" gradientUnits="userSpaceOnUse" cx="900" cy="150" r="260">
          <stop offset="0" stopColor="#fff" stopOpacity="1" />
          <stop offset=".55" stopColor="#fff" stopOpacity=".85" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <mask id="shelf-mask"><rect x="600" y="0" width="300" height="420" fill="url(#shelf-fade)" /></mask>
      </defs>
      <g mask="url(#shelf-mask)">
        <rect x="700" y="0" width="200" height="470" fill="#4a3358" />
        {Array.from({ length: 24 }).map((_, i) => {
          const row = Math.floor(i / 8), col = i % 8;
          return <rect key={i} x={712 + col * 22} y={30 + row * 130 + (i % 3) * 9} width="17" height={96 - (i % 3) * 9} rx="2" fill={["#8c4b3a", "#5b3a4f", "#a0743d", "#3f5a52", "#6e3030", "#9a7b55"][i % 6]} />;
        })}
        <path d="M700 128H900M700 258H900M700 388H900" stroke="#2a1b33" strokeWidth="5" opacity=".7" />
      </g>
    </svg>
  );
}

// ---------------------------------------------------------------- create page background
export function CreateArt() {
  const sp = useMemo(() => sparkles(60, 130, 160, 480, 640, 21), []);
  const jar = useMemo(() => sparkles(5, 1370, 690, 1450, 770, 3), []);
  return (
    <svg className="create-art" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="c-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fdeee6" />
          <stop offset=".55" stopColor="#f6e6f2" />
          <stop offset="1" stopColor="#f1e3f6" />
        </linearGradient>
        <radialGradient id="glow" cx=".5" cy=".5" r=".5">
          <stop offset="0" stopColor="#fff6cf" stopOpacity="1" />
          <stop offset=".35" stopColor="#ffd072" stopOpacity=".75" />
          <stop offset="1" stopColor="#ff9f5a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="c-swirl" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#ffe9a8" />
          <stop offset="1" stopColor="#ffbf5e" />
        </linearGradient>
        <linearGradient id="c-table" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f3cfae" />
          <stop offset="1" stopColor="#d9a77c" />
        </linearGradient>
        <radialGradient id="c-light" cx=".5" cy=".4" r=".7">
          <stop offset="0" stopColor="#fff" stopOpacity=".95" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <filter id="c-soft"><feGaussianBlur stdDeviation="6" /></filter>
      </defs>
      <rect width="1600" height="900" fill="url(#c-bg)" />
      {/* window light on the right */}
      <ellipse cx="1480" cy="230" rx="320" ry="360" fill="url(#c-light)" />
      <path d="M1380 40 Q1480 -40 1600 40 V430 H1380Z" fill="#fff" opacity=".55" />
      <path d="M1490 10 V430 M1380 220 H1600" stroke="#e9dccb" strokeWidth="6" opacity=".8" />
      {/* hill, castle, mountains on the left */}
      <path d="M-40 560 Q160 330 330 400 Q430 440 520 560 V760 H-40Z" fill="#8d95c8" opacity=".55" />
      <path d="M-40 640 Q130 440 300 500 Q420 540 500 660 V760 H-40Z" fill="#6e7db5" opacity=".7" />
      <Castle x={180} y={200} scale={1.7} fill="#5a4e92" />
      <g fill="none" strokeLinecap="round">
        <path d="M235 690 C 130 600, 330 600, 280 500 S 420 440, 350 330 S 150 200, 230 120" stroke="url(#c-swirl)" strokeWidth="22" filter="url(#c-soft)" opacity=".8" />
        <path d="M235 690 C 130 600, 330 600, 280 500 S 420 440, 350 330 S 150 200, 230 120" stroke="#fff6cf" strokeWidth="4" />
      </g>
      {sp.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={p.s * 1.3} fill="#fff1b0" opacity={p.o} />)}
      {/* table */}
      <path d="M0 770 Q 500 740 1600 775 V900 H0Z" fill="url(#c-table)" />
      <MagicBook cx={250} cy={700} w={0.95} />
      {/* right: book stack and star jar */}
      <g>
        <rect x="1330" y="620" width="270" height="62" rx="5" fill="#5a3a3a" />
        <rect x="1350" y="565" width="250" height="58" rx="5" fill="#7a4030" />
        <rect x="1370" y="512" width="230" height="54" rx="5" fill="#8d6a3f" />
        <g stroke="#e8c776" strokeWidth="2" fill="none">
          <path d="M1345 652h255M1365 594h235M1385 540h215" />
          <path d="M1420 640l20 -16 20 16M1440 582l20 -14 20 14" />
        </g>
        <rect x="1330" y="682" width="270" height="48" rx="5" fill="#40292e" />
      </g>
      <g>
        <ellipse cx="1405" cy="735" rx="110" ry="80" fill="url(#glow)" opacity=".9" />
        <rect x="1352" y="660" width="106" height="124" rx="22" fill="#fff" opacity=".35" stroke="#fff" strokeWidth="3" />
        <rect x="1366" y="640" width="78" height="26" rx="6" fill="#b88a5a" />
        {jar.map((p, i) => <Star key={i} x={p.x} y={p.y} s={12 + i * 2} fill="#ffd36a" />)}
        <Star x="1405" y="730" s="20" fill="#ffe28a" />
      </g>
      {/* leaves */}
      <g fill="#4d7a52" opacity=".9">
        <ellipse cx="30" cy="330" rx="70" ry="22" transform="rotate(-35 30 330)" />
        <ellipse cx="55" cy="400" rx="64" ry="20" transform="rotate(25 55 400)" />
        <ellipse cx="20" cy="470" rx="60" ry="18" transform="rotate(-10 20 470)" />
        <ellipse cx="40" cy="790" rx="80" ry="24" transform="rotate(-30 40 790)" fill="#3f6a47" />
        <ellipse cx="1560" cy="470" rx="60" ry="18" transform="rotate(25 1560 470)" />
      </g>
      {/* purple wave at the bottom */}
      <path d="M0 880 Q 400 820 800 850 T 1600 840 V900 H0Z" fill="#3b2a6b" />
    </svg>
  );
}

// ---------------------------------------------------------------- example covers (200 x 300)
const COVERS = {
  forest: {
    title: ["The Secret", "of the", "Whispering", "Forest"],
    color: "#f6f2d4",
    art: (
      <>
        <rect width="200" height="300" fill="#12341f" />
        <rect width="200" height="300" fill="url(#cv-forest)" />
        {[10, 38, 150, 176].map((x, i) => <rect key={i} x={x} y={90 + (i % 2) * 20} width={14 + (i % 2) * 6} height="220" fill="#0a1f13" />)}
        <path d="M70 300 L100 150 L130 300Z" fill="url(#cv-path)" />
        <circle cx="100" cy="196" r="7" fill="#0a1f13" />
        <path d="M100 203 L88 248 H112Z" fill="#0a1f13" />
        <g fill="#c9f7a8" opacity=".8">{[[40, 150], [160, 140], [58, 200], [150, 210], [120, 120]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="2" />)}</g>
      </>
    ),
  },
  stars: {
    title: ["Beyond", "the Stars"],
    color: "#f3f0ff",
    art: (
      <>
        <rect width="200" height="300" fill="url(#cv-night)" />
        {Array.from({ length: 40 }).map((_, i) => <circle key={i} cx={(i * 53) % 200} cy={(i * 97) % 280} r={(i % 3) * 0.5 + 0.6} fill="#fff" opacity={0.5 + (i % 4) * 0.12} />)}
        <circle cx="100" cy="190" r="34" fill="url(#cv-sun)" />
        <Star x={100} y={190} s={24} fill="#fff" />
        <path d="M0 260 Q100 200 200 262 V300 H0Z" fill="#0d0c2e" />
        <circle cx="100" cy="226" r="5" fill="#05051a" />
        <path d="M100 231 L92 258 H108Z" fill="#05051a" />
      </>
    ),
  },
  kingdom: {
    title: ["The Lost", "Kingdom"],
    color: "#ffe39a",
    art: (
      <>
        <rect width="200" height="300" fill="url(#cv-sunset)" />
        <ellipse cx="60" cy="140" rx="70" ry="14" fill="#ffd9a0" opacity=".5" />
        <ellipse cx="150" cy="170" rx="60" ry="12" fill="#ffd9a0" opacity=".4" />
        <path d="M0 250 Q100 190 200 250 V300 H0Z" fill="#2a2150" />
        <Castle x={64} y={150} scale={0.55} fill="#2a2150" glow={false} />
        <Star x={100} y={118} s={7} fill="#ffe9a8" />
      </>
    ),
  },
  dreams: {
    title: ["A Tale of", "Dreams"],
    color: "#4a2748",
    art: (
      <>
        <rect width="200" height="300" fill="url(#cv-pink)" />
        <path d="M0 270 Q100 230 200 275 V300 H0Z" fill="#c487a9" />
        <path d="M70 300 L96 215 H104 L130 300Z" fill="#f8d7e6" opacity=".8" />
        <g fill="#f6a6c8">{[[30, 130, 26], [60, 100, 22], [20, 170, 20], [165, 120, 28], [140, 90, 22], [178, 170, 20]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} />)}</g>
        <path d="M30 150 V230 M165 150 V230" stroke="#6a3b4c" strokeWidth="6" />
        <circle cx="100" cy="205" r="6" fill="#4a2748" />
        <path d="M100 211 L90 250 H110Z" fill="#4a2748" />
      </>
    ),
  },
  traveler: {
    title: ["The Time", "Traveler"],
    color: "#ffd77a",
    art: (
      <>
        <rect width="200" height="300" fill="#140d06" />
        <circle cx="100" cy="190" r="78" fill="url(#cv-gold)" />
        <circle cx="100" cy="190" r="62" fill="none" stroke="#ffd37a" strokeWidth="3" />
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i * Math.PI) / 6;
          return <path key={i} d={`M${100 + Math.sin(a) * 52} ${190 - Math.cos(a) * 52}L${100 + Math.sin(a) * 60} ${190 - Math.cos(a) * 60}`} stroke="#ffd37a" strokeWidth="2.4" />;
        })}
        <path d="M100 190V150M100 190L126 204" stroke="#ffe8b0" strokeWidth="3" strokeLinecap="round" />
        <g fill="#140d06">
          <circle cx="82" cy="244" r="6" /><path d="M82 250L72 284H92Z" />
          <circle cx="118" cy="248" r="5" /><path d="M118 253L110 284H126Z" />
        </g>
      </>
    ),
  },
};

export function ExampleCover({ kind, className = "" }) {
  const c = COVERS[kind];
  return (
    <svg className={`ex-cover ${className}`} viewBox="0 0 200 300" role="img" aria-label={c.title.join(" ")}>
      <defs>
        <linearGradient id="cv-forest" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#1e5a3a" /><stop offset="1" stopColor="#0b2616" /></linearGradient>
        <linearGradient id="cv-path" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#e9ffd0" stopOpacity=".95" /><stop offset="1" stopColor="#7fd98a" stopOpacity=".4" /></linearGradient>
        <linearGradient id="cv-night" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0c1048" /><stop offset=".6" stopColor="#3a1f7a" /><stop offset="1" stopColor="#1a1450" /></linearGradient>
        <radialGradient id="cv-sun" cx=".5" cy=".5" r=".5"><stop offset="0" stopColor="#fff" /><stop offset=".4" stopColor="#bda6ff" stopOpacity=".8" /><stop offset="1" stopColor="#6a4be0" stopOpacity="0" /></radialGradient>
        <linearGradient id="cv-sunset" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#5a3b9a" /><stop offset=".5" stopColor="#f08a5d" /><stop offset="1" stopColor="#ffd27a" /></linearGradient>
        <linearGradient id="cv-pink" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f9c5dc" /><stop offset="1" stopColor="#c8a2e8" /></linearGradient>
        <radialGradient id="cv-gold" cx=".5" cy=".5" r=".5"><stop offset="0" stopColor="#ffb83a" stopOpacity=".55" /><stop offset="1" stopColor="#ff8a1a" stopOpacity=".05" /></radialGradient>
      </defs>
      {c.art}
      <rect width="200" height="92" fill="#000" opacity="0" />
      <text x="100" y="42" textAnchor="middle" fontFamily="'Playfair Display', Georgia, serif" fontWeight="700" fontSize={c.title.length > 2 ? 21 : 26} fill={c.color} stroke="rgba(0,0,0,.25)" strokeWidth=".6">
        {c.title.map((t, i) => <tspan key={i} x="100" dy={i === 0 ? 0 : c.title.length > 2 ? 22 : 28}>{t}</tspan>)}
      </text>
    </svg>
  );
}

export const EXAMPLES = ["forest", "stars", "kingdom", "dreams", "traveler"];
