import React, { useState } from "react";
import Icon, { Logo } from "./Icon.jsx";
import { useAuth } from "./auth.jsx";

export default function LoginModal() {
  const { open, closeLogin, login } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  if (!open) return null;

  function submit(e) {
    e.preventDefault();
    login({ name: name.trim(), email: email.trim() });
    closeLogin();
  }

  return (
    <div className="modal-back" onClick={closeLogin}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <button type="button" className="modal-x" onClick={closeLogin} aria-label="Close"><Icon name="close" size={18} /></button>
        <Logo size={52} />
        <h2>Welcome, author</h2>
        <p className="muted">Create your author profile. Your name is filled in automatically on every book.</p>
        <label>Your name
          <input required autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
        </label>
        <label>Email (optional)
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </label>
        <button className="btn primary wide">Continue</button>
        <small className="muted">Your profile and books are stored on this device only. Cloud accounts are coming next.</small>
      </form>
    </div>
  );
}
