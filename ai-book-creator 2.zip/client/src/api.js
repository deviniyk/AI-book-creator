async function post(path, body) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error("Cannot reach the backend server. Make sure it is running (npm start) and refresh this page.");
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Request failed (${res.status}).`);
  }
  return res;
}

// retry a flaky AI call a couple of times before giving up
export async function withRetry(fn, tries = 3) {
  let last;
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      if (/Cannot reach the backend|at least 10 characters/.test(e.message)) break;
      await new Promise((r) => setTimeout(r, 1200 * (i + 1)));
    }
  }
  throw last;
}

export async function getStatus() {
  try {
    const res = await fetch("/api/status");
    return await res.json();
  } catch {
    return { ok: false };
  }
}

export const generateOutline = async (payload) => (await post("/outline", payload)).json();
export const writeChapter = async (payload) => (await post("/chapter", payload)).json();
export const generateCover = async (payload) => (await post("/cover", payload)).json();

export async function downloadPdf({ book, frontCover, backCover }) {
  const res = await post("/export-pdf", { book, frontCover, backCover });
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${(book.title || "book").replace(/[\\/:*?"<>|]+/g, "").trim().replace(/\s+/g, "_") || "book"}.pdf`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
