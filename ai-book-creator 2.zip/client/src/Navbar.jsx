import React, { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import Icon, { Logo } from "./Icon.jsx";
import { useAuth, useTheme } from "./auth.jsx";

export default function Navbar() {
  const { user, logout, openLogin } = useAuth();
  const [theme, toggleTheme] = useTheme();
  const [menu, setMenu] = useState(false);
  const loc = useLocation();
  useEffect(() => setMenu(false), [loc.pathname]);

  const links = [
    ["/", "Home", "home"],
    ["/library", "My Books"],
    ["/about", "About"],
    ["/faq", "FAQ"],
  ];

  return (
    <header className="nav">
      <Link to="/" className="brand">
        <Logo size={42} />
        <span>AI Book Creator</span>
      </Link>

      <nav className={`navlinks ${menu ? "open" : ""}`}>
        {links.map(([to, label, icon]) => (
          <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => (isActive ? "active" : "")}>
            {icon && <Icon name={icon} size={17} />}
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="nav-right">
        <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle light and dark theme" title="Toggle theme">
          <Icon name={theme === "light" ? "sun" : "moon"} size={19} />
        </button>
        {user ? (
          <>
            <span className="avatar" title={user.name}>{(user.name || "?").slice(0, 1).toUpperCase()}</span>
            <button className="btn dark" onClick={logout}><Icon name="logout" size={17} /> Logout</button>
          </>
        ) : (
          <button className="btn dark" onClick={openLogin}><Icon name="user" size={17} /> Login</button>
        )}
        <button className="icon-btn menu-btn" onClick={() => setMenu(!menu)} aria-label="Menu">
          <Icon name={menu ? "close" : "menu"} size={20} />
        </button>
      </div>
    </header>
  );
}
