import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { mode, makeOutline, writeChapter, makeCover } from "./ai.js";
import { buildPdf } from "./pdf.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({ limit: "40mb" }));

const fail = (res, err, fallback) => {
  console.error(err);
  const msg = err?.error?.message || err?.message || fallback;
  res.status(500).json({ error: `${fallback} (${msg})` });
};

// Tells the frontend whether real AI or demo mode is active.
app.get("/api/status", (_req, res) => res.json({ ok: true, mode }));
app.get("/api/health", (_req, res) => res.json({ ok: true, mode }));

// 1. Plan the book: title, tagline, back-cover summary, characters, chapter list, cover prompt
app.post("/api/outline", async (req, res) => {
  const { idea } = req.body;
  if (!idea || idea.trim().length < 10) return res.status(400).json({ error: "Please describe your story idea (at least 10 characters)." });
  try {
    res.json(await makeOutline(req.body));
  } catch (err) {
    fail(res, err, "Could not plan the book");
  }
});

// 2. Write one chapter (also used to regenerate a chapter)
app.post("/api/chapter", async (req, res) => {
  try {
    const { outline, index } = req.body;
    if (!outline?.chapters?.[index]) return res.status(400).json({ error: "Invalid chapter." });
    const content = await writeChapter(req.body);
    res.json({ content });
  } catch (err) {
    fail(res, err, "Could not write the chapter");
  }
});

// 3. Cover artwork (no text in the image; title/author are typeset by the app)
app.post("/api/cover", async (req, res) => {
  try {
    res.json({ image: await makeCover(req.body) });
  } catch (err) {
    fail(res, err, "Could not create the cover artwork");
  }
});

// 4. PDF eBook
app.post("/api/export-pdf", (req, res) => {
  try {
    const { book } = req.body;
    if (!book?.chapters?.length) return res.status(400).json({ error: "Nothing to export." });
    const safe = (book.title || "book").replace(/[^\p{L}\p{N}\- ]+/gu, "").trim().replace(/\s+/g, "_") || "book";
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="book.pdf"; filename*=UTF-8''${encodeURIComponent(safe)}.pdf`);
    buildPdf(req.body, res);
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.status(500).json({ error: "PDF export failed." });
  }
});

// Serve the built React app so one command runs everything
const dist = path.join(__dirname, "..", "client", "dist");
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get("*", (_req, res) => res.sendFile(path.join(dist, "index.html")));
}

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\nAI Book Creator running: http://localhost:${PORT}`);
  console.log(mode === "openai" ? "AI mode: OpenAI connected." : "DEMO mode: no OpenAI key found in server/.env (sample text, no artwork).");
});
