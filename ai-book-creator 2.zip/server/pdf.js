import PDFDocument from "pdfkit";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// A5 trade-paperback page
const W = 419.53;
const H = 595.28;
const M = { top: 64, bottom: 70, left: 52, right: 52 };
const TEXT_W = W - M.left - M.right;

const PLUM = "#1f1433";
const GOLD = "#d9b96b";
const CREAM = "#fdf8ee";

// ------------------------------------------------------------ labels
// Fixed book text in each language (the Sinhala/Tamil fonts have no Latin letters or digits)
const LABELS = {
  English: {
    contents: "Contents", characters: "Characters", about: "About the Author", chapter: "CHAPTER",
    rights: "All rights reserved.",
    ai: "This book was created from the author's original idea with the assistance of artificial intelligence. The author has reviewed and edited the content.",
    fiction: "Names, characters and events are the product of imagination unless stated otherwise. Any resemblance to real persons or events is coincidental.",
    made: "Created with AI Book Creator.",
    aboutText: (a, t) => `${a || "The author"} created "${t}" from an original idea, working together with AI to bring the story to the page.`,
  },
  Sinhala: {
    contents: "පටුන", characters: "චරිත", about: "කතුවරයා ගැන", chapter: "පරිච්ඡේදය",
    rights: "සියලුම හිමිකම් ඇවිරිණි.",
    ai: "මෙම පොත කතුවරයාගේ මුල් අදහසෙන්, කෘතිම බුද්ධියේ සහාය ඇතිව නිර්මාණය කරන ලදී. කතුවරයා අන්තර්ගතය සමාලෝචනය කර සංස්කරණය කර ඇත.",
    fiction: "",
    made: "",
    aboutText: (a, t) => `${a} විසින් මුල් අදහසකින් ආරම්භ කර, කෘතිම බුද්ධියේ සහාය ඇතිව "${t}" කතාව නිර්මාණය කරන ලදී.`,
  },
  Tamil: {
    contents: "உள்ளடக்கம்", characters: "கதாபாத்திரங்கள்", about: "ஆசிரியர் பற்றி", chapter: "அத்தியாயம்",
    rights: "அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.",
    ai: "இந்த நூல் ஆசிரியரின் சொந்த யோசனையிலிருந்து செயற்கை நுண்ணறிவின் உதவியுடன் உருவாக்கப்பட்டது. ஆசிரியர் உள்ளடக்கத்தை மதிப்பாய்வு செய்து திருத்தியுள்ளார்.",
    fiction: "",
    made: "",
    aboutText: (a, t) => `${a} தனது சொந்த யோசனையிலிருந்து, செயற்கை நுண்ணறிவின் உதவியுடன் "${t}" நூலை உருவாக்கினார்.`,
  },
};

// ------------------------------------------------------------ fonts
function setupFonts(doc, language) {
  const files = {
    Sinhala: ["NotoSansSinhala-Regular.ttf", "NotoSansSinhala-Bold.ttf"],
    Tamil: ["NotoSansTamil-Regular.ttf", "NotoSansTamil-Bold.ttf"],
  }[language];
  if (files) {
    const reg = path.join(__dirname, "fonts", files[0]);
    const bold = path.join(__dirname, "fonts", files[1]);
    if (fs.existsSync(reg) && fs.existsSync(bold)) {
      doc.registerFont("body", reg);
      doc.registerFont("bold", bold);
      doc.registerFont("italic", reg);
      return { body: "body", bold: "bold", italic: "italic", num: "Times-Roman", complex: true, L: LABELS[language] };
    }
  }
  return { body: "Times-Roman", bold: "Times-Bold", italic: "Times-Italic", num: "Times-Roman", complex: false, L: LABELS.English };
}

// shrink font size until text fits in maxH
function fit(doc, text, font, max, min, width, maxH, extra = {}) {
  let size = max;
  doc.font(font);
  while (size > min) {
    doc.fontSize(size);
    if (doc.heightOfString(text, { width, ...extra }) <= maxH) break;
    size -= 1;
  }
  return size;
}

function dataToBuffer(dataUrl) {
  return Buffer.from(String(dataUrl).split(",")[1], "base64");
}

function drawImageCover(doc, dataUrl) {
  doc.save();
  doc.rect(0, 0, W, H).clip();
  doc.image(dataToBuffer(dataUrl), 0, 0, { cover: [W, H], align: "center", valign: "center" });
  doc.restore();
}

function drawDesignedBackground(doc) {
  const g = doc.linearGradient(0, 0, W, H);
  g.stop(0, "#4a2678").stop(0.55, "#2a1747").stop(1, "#150c26");
  doc.rect(0, 0, W, H).fill(g);
  doc.lineWidth(1.6).strokeColor(GOLD).rect(18, 18, W - 36, H - 36).stroke();
  doc.lineWidth(0.6).strokeColor(GOLD).rect(24, 24, W - 48, H - 48).stroke();
}

function fadeBand(doc, y, h, topAlpha, bottomAlpha) {
  const g = doc.linearGradient(0, y, 0, y + h);
  g.stop(0, PLUM, topAlpha).stop(1, PLUM, bottomAlpha);
  doc.rect(0, y, W, h).fill(g);
}

// ------------------------------------------------------------ pages
// fixed-layout pages (covers etc.): no bottom margin, so text near the edge never spills onto a new page
function fixedPage(doc) {
  doc.addPage();
  doc.page.margins.bottom = 0;
}

function frontCover(doc, F, book, image) {
  fixedPage(doc);
  if (image) {
    drawImageCover(doc, image);
    fadeBand(doc, 0, 250, 0.88, 0);
    fadeBand(doc, H - 130, 130, 0, 0.88);
  } else {
    drawDesignedBackground(doc);
  }

  const x = 42;
  const w = W - 84;
  const title = String(book.title || "Untitled");
  const size = fit(doc, title, F.bold, 34, 18, w, 150);
  doc.fillColor(CREAM).font(F.bold).fontSize(size).text(title, x, image ? 60 : 95, { width: w, align: "center" });

  const afterTitle = doc.y + 14;
  doc.lineWidth(0.8).strokeColor(GOLD).moveTo(W / 2 - 40, afterTitle).lineTo(W / 2 + 40, afterTitle).stroke();
  if (book.tagline) {
    doc.fillColor(CREAM).font(F.italic).fontSize(12).text(book.tagline, x, afterTitle + 12, { width: w, align: "center" });
  }

  const author = String(book.author || "");
  if (!F.complex) doc.fillColor(CREAM).font(F.body).fontSize(10).text(String(book.genre || "").toUpperCase(), x, H - 92, { width: w, align: "center", characterSpacing: 2 });
  const asize = fit(doc, author, F.bold, 20, 12, w, 30);
  doc.fillColor(CREAM).font(F.bold).fontSize(asize).text(author, x, H - 72, { width: w, align: "center" });
}

function titlePage(doc, F, book) {
  fixedPage(doc);
  const w = TEXT_W;
  const title = String(book.title || "Untitled");
  const size = fit(doc, title, F.bold, 30, 18, w, 180);
  doc.fillColor(PLUM).font(F.bold).fontSize(size).text(title, M.left, 170, { width: w, align: "center" });
  const y = doc.y + 16;
  doc.lineWidth(0.8).strokeColor(GOLD).moveTo(W / 2 - 30, y).lineTo(W / 2 + 30, y).stroke();
  doc.fillColor("#444").font(F.italic).fontSize(13).text(String(book.tagline || ""), M.left, y + 14, { width: w, align: "center" });
  doc.fillColor(PLUM).font(F.body).fontSize(15).text(String(book.author || ""), M.left, H - 150, { width: w, align: "center" });
}

function copyrightPage(doc, F, book) {
  fixedPage(doc);
  const L = F.L;
  const year = new Date().getFullYear();
  doc.fillColor("#555").font(F.body).fontSize(9.5);
  doc.text(String(book.title || ""), M.left, H - 260, { width: TEXT_W, lineGap: 3 });
  doc.font(F.num).text(`Copyright © ${year}`, M.left, doc.y + 2, { width: TEXT_W, lineGap: 3, continued: true });
  doc.font(F.body).text(`  ${book.author || ""}`, { width: TEXT_W });
  const rest = [L.rights, "", L.ai, "", L.fiction, L.fiction ? "" : null, L.made].filter((x) => x !== null);
  doc.font(F.body).text(rest.join("\n"), M.left, doc.y + 2, { width: TEXT_W, lineGap: 3 });
}

function chapterPage(doc, F, ch) {
  doc.addPage();
  doc.x = M.left;
  doc.fillColor("#8a6bb5").font(F.body).fontSize(10).text(F.L.chapter + " ", M.left, M.top + 20, { width: TEXT_W, align: "center", characterSpacing: 2, continued: true });
  doc.font(F.num).text(String(ch.number), { width: TEXT_W, align: "center", characterSpacing: 2 });
  const title = String(ch.title || "");
  const size = fit(doc, title, F.bold, 22, 14, TEXT_W, 80);
  doc.fillColor(PLUM).font(F.bold).fontSize(size).text(title, M.left, doc.y + 6, { width: TEXT_W, align: "center" });
  const y = doc.y + 10;
  doc.lineWidth(0.8).strokeColor(GOLD).moveTo(W / 2 - 24, y).lineTo(W / 2 + 24, y).stroke();

  doc.x = M.left;
  doc.y = y + 22;
  doc.fillColor("#222").font(F.body).fontSize(11.5);
  const paras = String(ch.content || "").split(/\n+/).map((p) => p.trim()).filter(Boolean);
  paras.forEach((p, i) => {
    doc.text(p, M.left, doc.y, { width: TEXT_W, align: F.complex ? "left" : "justify", lineGap: 3.5, paragraphGap: 7, indent: i === 0 ? 0 : 16 });
  });
}

function aboutAuthorPage(doc, F, book) {
  doc.addPage();
  doc.fillColor(PLUM).font(F.bold).fontSize(20).text(F.L.about, M.left, M.top + 30, { width: TEXT_W, align: "center" });
  const y = doc.y + 10;
  doc.lineWidth(0.8).strokeColor(GOLD).moveTo(W / 2 - 24, y).lineTo(W / 2 + 24, y).stroke();
  doc.fillColor("#222").font(F.bold).fontSize(14).text(String(book.author || ""), M.left, y + 24, { width: TEXT_W, align: "center" });
  doc.fillColor("#333").font(F.body).fontSize(11.5).text(
    F.L.aboutText(book.author, book.title),
    M.left, doc.y + 12, { width: TEXT_W, align: "center", lineGap: 4 }
  );
}

function backCover(doc, F, book, image) {
  fixedPage(doc);
  if (image) {
    drawImageCover(doc, image);
    doc.save().rect(0, 0, W, H).fillOpacity(0.35).fill(PLUM).restore();
  } else {
    drawDesignedBackground(doc);
  }
  const px = 38, py = 70, pw = W - 76, ph = H - 150;
  doc.save().roundedRect(px, py, pw, ph, 6).fillOpacity(0.72).fill(PLUM).restore();

  const ix = px + 20, iw = pw - 40;
  doc.fillColor(CREAM).font(F.bold).fontSize(fit(doc, String(book.title), F.bold, 17, 11, iw, 50)).text(String(book.title || ""), ix, py + 22, { width: iw, align: "center" });
  const y = doc.y + 10;
  doc.lineWidth(0.8).strokeColor(GOLD).moveTo(W / 2 - 24, y).lineTo(W / 2 + 24, y).stroke();

  const summary = String(book.summary || "");
  const sSize = fit(doc, summary, F.body, 11.5, 8, iw, ph - 190, { lineGap: 3 });
  doc.fillColor(CREAM).font(F.body).fontSize(sSize).text(summary, ix, y + 16, { width: iw, align: "center", lineGap: 3 });

  doc.fillColor(GOLD).font(F.body).fontSize(9).text(F.complex ? F.L.about : F.L.about.toUpperCase(), ix, py + ph - 62, { width: iw, align: "center", characterSpacing: 2 });
  doc.fillColor(CREAM).font(F.bold).fontSize(13).text(String(book.author || ""), ix, doc.y + 4, { width: iw, align: "center" });
}

function contentsPage(doc, F) {
  doc.addPage();
  doc.fillColor(PLUM).font(F.bold).fontSize(20).text(F.L.contents, M.left, M.top + 20, { width: TEXT_W, align: "center" });
  return doc.bufferedPageRange().count - 1;
}

function fillContents(doc, F, pageIndex, chapters, numbers) {
  doc.switchToPage(pageIndex);
  let y = M.top + 80;
  const step = Math.min(28, (H - M.bottom - y) / Math.max(chapters.length, 1));
  chapters.forEach((c, i) => {
    doc.fillColor("#222").font(F.body).fontSize(11.5);
    doc.font(F.num).text(`${c.number}.`, M.left + 10, y, { width: 24, lineBreak: false });
    doc.font(F.body).text(String(c.title), M.left + 34, y, { width: TEXT_W - 80, lineBreak: false, ellipsis: true });
    doc.font(F.num).text(String(numbers[i]), M.left, y, { width: TEXT_W - 10, align: "right", lineBreak: false });
    doc.lineWidth(0.3).strokeColor("#ddd").moveTo(M.left + 10, y + 17).lineTo(W - M.right - 10, y + 17).stroke();
    y += step;
  });
}

function charactersPage(doc, F, characters) {
  doc.addPage();
  doc.fillColor(PLUM).font(F.bold).fontSize(20).text(F.L.characters, M.left, M.top + 20, { width: TEXT_W, align: "center" });
  doc.x = M.left;
  doc.y += 18;
  for (const c of characters) {
    doc.fillColor(PLUM).font(F.bold).fontSize(12).text(String(c.name || ""), M.left, doc.y, { width: TEXT_W });
    doc.fillColor("#333").font(F.body).fontSize(11).text(String(c.description || ""), M.left, doc.y + 1, { width: TEXT_W, lineGap: 2.5 });
    doc.y += 10;
  }
}

function pageNumbers(doc, F, first, last) {
  const range = doc.bufferedPageRange();
  for (let i = first; i <= Math.min(last, range.start + range.count - 1); i++) {
    doc.switchToPage(i);
    doc.page.margins.bottom = 0; // avoid auto-creating a new page when writing the footer
    doc.fillColor("#8a8a8a").font(F.num).fontSize(9).text(String(i - first + 1), 0, H - 40, { width: W, align: "center", lineBreak: false });
  }
}

// ------------------------------------------------------------ main
export function buildPdf({ book, frontCover: front, backCover: back }, out) {
  const doc = new PDFDocument({
    size: [W, H],
    margins: { top: M.top, bottom: M.bottom, left: M.left, right: M.right },
    autoFirstPage: false,
    bufferPages: true,
    info: { Title: book.title || "Untitled", Author: book.author || "", Creator: "AI Book Creator" },
  });
  doc.pipe(out);
  const F = setupFonts(doc, book.language);

  frontCover(doc, F, book, front);
  titlePage(doc, F, book);
  copyrightPage(doc, F, book);
  const tocIndex = contentsPage(doc, F);
  if (book.characters?.length) charactersPage(doc, F, book.characters);

  const chapterStarts = [];
  let firstChapter = null;
  for (const ch of book.chapters) {
    chapterPage(doc, F, ch);
    const idx = doc.bufferedPageRange().count - 1;
    if (firstChapter === null) firstChapter = idx;
    chapterStarts.push(idx);
  }
  aboutAuthorPage(doc, F, book);
  const lastBodyIndex = doc.bufferedPageRange().count - 1;
  backCover(doc, F, book, back);

  fillContents(doc, F, tocIndex, book.chapters, chapterStarts.map((i) => i - firstChapter + 1));
  pageNumbers(doc, F, firstChapter, lastBodyIndex);

  doc.flushPages();
  doc.end();
}
