import OpenAI from "openai";

const key = (process.env.OPENAI_API_KEY || "").trim();
export const hasKey = key.length > 20 && !key.toLowerCase().startsWith("your-");
export const mode = hasKey ? "openai" : "demo";

const openai = hasKey ? new OpenAI({ apiKey: key }) : null;
const TEXT_MODEL = process.env.OPENAI_TEXT_MODEL || "gpt-4o-mini";
const IMAGE_MODEL = process.env.OPENAI_IMAGE_MODEL || "gpt-image-1";

export const WORDS = { short: 300, medium: 600, long: 1000 };

// ------------------------------------------------------------------ outline
export async function makeOutline({ idea, genre, language, chapters, length, authorName, characterCount }) {
  const n = Math.min(Math.max(Number(chapters) || 5, 1), 15);
  if (!openai) return demoOutline({ idea, genre, language, n, authorName, cc: Math.min(Math.max(Number(characterCount) || 4, 1), 14) });

  const completion = await openai.chat.completions.create({
    model: TEXT_MODEL,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content:
          "You are an award-winning author and book editor. Reply with valid JSON only. " +
          "Plan original, coherent, age-appropriate books with a satisfying ending.",
      },
      {
        role: "user",
        content: `Plan a ${genre} book in ${language} from this idea:
"""${idea}"""

Return JSON in exactly this shape:
{
  "title": "memorable book title in ${language}",
  "tagline": "one short line in ${language}",
  "summary": "back-cover blurb, 60-90 words, in ${language}",
  "characters": [{"name": "", "description": "one or two sentences in ${language}"}],
  "coverPrompt": "English visual description of cover artwork, no text or lettering in the image",
  "chapters": [{"number": 1, "title": "chapter title in ${language}", "beats": "2-3 sentences in English on what happens"}]
}
There must be exactly ${n} chapters, forming a complete story arc with a clear ending in the last chapter.
List about ${characterCount || 4} named characters in the "characters" array (main characters first).`,
      },
    ],
  });

  const o = JSON.parse(completion.choices[0].message.content);
  o.chapters = (o.chapters || []).slice(0, n).map((c, i) => ({ number: i + 1, title: c.title || `Chapter ${i + 1}`, beats: c.beats || "" }));
  while (o.chapters.length < n) {
    const i = o.chapters.length;
    o.chapters.push({ number: i + 1, title: `Chapter ${i + 1}`, beats: "Continue the story toward its ending." });
  }
  return { ...o, author: authorName, genre, language };
}

// ------------------------------------------------------------------ chapters
export async function writeChapter({ outline, index, previousText = "", instruction = "", length = "medium", wordsPerChapter }) {
  const ch = outline.chapters[index];
  if (!openai) return demoChapter(outline, index);

  const words = Math.min(Math.max(Number(wordsPerChapter) || WORDS[length] || WORDS.medium, 150), 1500);
  const isLast = index === outline.chapters.length - 1;
  const plan = outline.chapters.map((c) => `${c.number}. ${c.title}: ${c.beats}`).join("\n");
  const chars = (outline.characters || []).map((c) => `${c.name}: ${c.description}`).join("\n");

  const completion = await openai.chat.completions.create({
    model: TEXT_MODEL,
    max_tokens: Math.min(16000, Math.round(words * (outline.language === "English" ? 3 : 9))),
    messages: [
      {
        role: "system",
        content:
          "You are an award-winning novelist. Write polished, vivid prose with natural dialogue. " +
          "Output only the chapter text as plain paragraphs separated by blank lines: no title, no chapter heading, no markdown.",
      },
      {
        role: "user",
        content: `Book: "${outline.title}" (${outline.genre}, written in ${outline.language})
Summary: ${outline.summary}
Characters:
${chars}

Full chapter plan:
${plan}

${previousText ? "End of the previous chapter, for continuity:\n" + previousText.slice(-1500) + "\n" : ""}
Now write chapter ${ch.number}, "${ch.title}", in ${outline.language}, about ${words} words.
What happens: ${ch.beats}
${isLast ? "This is the final chapter: bring the story to a satisfying ending." : "Do not end the story yet."}
${instruction ? "Extra instruction from the author: " + instruction : ""}`,
      },
    ],
  });
  return completion.choices[0].message.content.trim();
}

// ------------------------------------------------------------------ covers
export async function makeCover({ coverPrompt, side = "front", style = "illustrated storybook" }) {
  if (!openai) throw new Error("Demo mode: no cover artwork. Add your OpenAI key to generate artwork.");
  const prompt =
    side === "front"
      ? `Book cover artwork, ${style} style: ${coverPrompt}. Portrait composition with calm open space at the top and bottom. Absolutely no text, letters, words or typography.`
      : `Back cover background artwork, ${style} style, soft and subtle, related to: ${coverPrompt}. Calm composition with large empty areas. Absolutely no text, letters, words or typography.`;

  if (IMAGE_MODEL.startsWith("dall-e")) {
    const img = await openai.images.generate({ model: IMAGE_MODEL, prompt, size: "1024x1792", response_format: "b64_json" });
    return `data:image/png;base64,${img.data[0].b64_json}`;
  }
  const img = await openai.images.generate({
    model: IMAGE_MODEL,
    prompt,
    size: "1024x1536",
    quality: "medium",
    output_format: "jpeg",
    output_compression: 80,
  });
  return `data:image/jpeg;base64,${img.data[0].b64_json}`;
}

// ------------------------------------------------------------------ demo mode
const DEMO_TITLES = {
  Fantasy: ["The Last Ember of Aurelia", "A kingdom of lantern-light and old magic"],
  Adventure: ["Beyond the Edge of the Map", "Some journeys choose the traveller"],
  Mystery: ["The Lighthouse Letters", "Every secret leaves a trace"],
  Romance: ["Letters Written in Monsoon", "Some stories wait for the right season"],
  "Science Fiction": ["Last Signal from Andromeda", "The future is listening"],
  Horror: ["The House Beneath the Fog", "Not every door should be opened"],
  "Children's Story": ["The Secret of the Whispering Forest", "A little courage goes a long way"],
  Historical: ["The Year of the Silver River", "History is made by ordinary hands"],
};

const DEMO_CHARS = [
  ["The Hero", "Curious and brave, driven by the idea at the heart of this story."],
  ["The Companion", "A loyal friend who sees what the hero cannot."],
  ["The Stranger", "Mysterious, with a secret that changes everything."],
  ["The Guardian", "An old protector who knows more than they say."],
  ["The Rival", "Clever and proud, always one step ahead or behind."],
  ["The Healer", "Gentle and wise, trusted by everyone."],
  ["The Trickster", "Never serious, never wrong about people."],
  ["The Elder", "Keeper of the old stories and the first warning."],
  ["The Messenger", "Quick, quiet, and always carrying news."],
  ["The Shadow", "A presence that follows the hero's doubts."],
  ["The Child", "Sees the truth plainly when no one else will."],
  ["The Traveller", "Arrives at exactly the wrong, and right, moment."],
  ["The Keeper", "Guards the place where the story began."],
  ["The Dreamer", "Believes the impossible is only unfinished."],
];

function demoOutline({ idea, genre, language, n, authorName, cc = 4 }) {
  const [title, tagline] = DEMO_TITLES[genre] || DEMO_TITLES.Fantasy;
  const titles = ["The Beginning", "A Strange Discovery", "Friends and Shadows", "The Journey", "The Turning Point", "The Hardest Choice", "The Storm", "A New Hope", "The Final Stand", "Home Again", "Whispers", "The Long Road", "Light at the End", "The Return", "Epilogue"];
  return {
    title,
    tagline,
    summary: `${idea.trim().slice(0, 220)} What begins as a simple moment soon becomes a journey of courage, friendship and discovery, where every choice matters and the ending is earned. (Demo mode sample text.)`,
    characters: DEMO_CHARS.slice(0, cc).map(([name, description]) => ({ name, description })),
    coverPrompt: idea.trim().slice(0, 300),
    chapters: Array.from({ length: n }, (_, i) => ({ number: i + 1, title: titles[i % titles.length], beats: "" })),
    author: authorName,
    genre,
    language,
  };
}

function demoChapter(outline, index) {
  const last = index === outline.chapters.length - 1;
  const first = index === 0;
  const p = [];
  if (first) p.push(`It all began with a single idea: ${outline.summary.split(" (Demo")[0]}`);
  else p.push(`The story continued, and with every step the hero understood a little more about what lay ahead.`);
  p.push(`“Are you sure about this?” asked the Companion, glancing at the path that stretched into the unknown.`);
  p.push(`“No,” the hero admitted with a smile, “but nobody ever found anything worthwhile by staying where it was safe.”`);
  p.push(`The air felt different here. Every sound seemed to carry a meaning, and every shadow seemed to hold a question. The Stranger watched from a distance, saying nothing, but never looking away.`);
  p.push(
    last
      ? `In the end, courage turned out to be quieter than anyone had imagined. The journey was over, but the hero knew that nothing would ever look the same again. And so the story closes, as all good stories do, with a beginning.`
      : `Night fell slowly. By the fire, they talked until the stars came out, and none of them could say what tomorrow would bring, only that they would face it together.`
  );
  p.push(`(This is demo-mode sample text. Add your OpenAI API key in server/.env to have the AI write the full chapter.)`);
  return p.join("\n\n");
}
